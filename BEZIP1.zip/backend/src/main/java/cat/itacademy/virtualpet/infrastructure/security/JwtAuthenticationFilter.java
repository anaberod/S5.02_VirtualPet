package cat.itacademy.virtualpet.infrastructure.security;

import cat.itacademy.virtualpet.domain.user.User;
import cat.itacademy.virtualpet.domain.user.UserRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Lee Authorization: Bearer <token>, lo valida con JwtService y
 * si es válido establece la Authentication en el SecurityContext.
 * Se ignoran: /auth/** y preflight OPTIONS.
 */
@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final UserRepository userRepository;

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain) throws ServletException, IOException {

        // Ignorar preflight y rutas públicas de auth
        if ("OPTIONS".equalsIgnoreCase(request.getMethod()) ||
                request.getRequestURI().startsWith("/auth")) {
            filterChain.doFilter(request, response);
            return;
        }

        // Extraer cabecera Authorization
        String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return; // No hay token → que siga la cadena (acabará en 401 por Security)
        }

        String token = authHeader.substring(7);

        // Si ya hay autenticación, no rehacerla
        if (SecurityContextHolder.getContext().getAuthentication() != null) {
            filterChain.doFilter(request, response);
            return;
        }

        try {
            // 1) Extraer email (esto valida firma y expiración; si falla lanza excepción)
            String email = jwtService.extractEmail(token);
            if (email == null) {
                filterChain.doFilter(request, response);
                return;
            }
            // 🔹 Normaliza como en BD
            email = email.trim().toLowerCase();

            // 2) Buscar usuario en BD
            User user = userRepository.findByEmail(email).orElse(null);

            Set<SimpleGrantedAuthority> authorities;

            if (user != null) {
                // 3a) Usuario existe → validar token contra el user y usar sus roles
                if (!jwtService.isTokenValid(token, user)) {
                    filterChain.doFilter(request, response);
                    return;
                }
                authorities = user.getRoles().stream()
                        .map(SimpleGrantedAuthority::new)
                        .collect(Collectors.toSet());
            } else {
                // 3b) Usuario NO existe pero el token ya fue validado al extraer el email
                //     → autentica con un rol mínimo (en tus tests: ROLE_USER)
                authorities = Collections.singleton(new SimpleGrantedAuthority("ROLE_USER"));
            }

            // 4) Establecer Authentication en el contexto
            UsernamePasswordAuthenticationToken auth =
                    new UsernamePasswordAuthenticationToken(email, null, authorities);
            SecurityContextHolder.getContext().setAuthentication(auth);

        } catch (Exception ex) {
            // Cualquier problema con el token → continuar (Security dará 401)
        }

        filterChain.doFilter(request, response);
    }
}
