package cat.itacademy.virtualpet.domain.pet.enums;

/**
 * Available dog breeds for the Virtual Pet.
 */
public enum Breed {
    DALMATIAN,
    LABRADOR,
    GOLDEN_RETRIEVER
}
